package com.example.fakenews.ForGesture2;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.cheng.channel.*;
import com.example.fakenews.*;
import com.example.fakenews.DataBase.NewsManager;
import com.example.fakenews.R;

import java.util.ArrayList;
import java.util.List;

public class ChannelActivity2 extends AppCompatActivity {

    private String TAG = getClass().getSimpleName();
    private ChannelView channelView;
    private ImageView button_close;

    private String username;

    ArrayList<String> userChannelList;
    ArrayList<String> otherChannelList;

    List<Channel> ch_userChannelList = new ArrayList<>();
    List<Channel> ch_otherChannelList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(com.example.fakenews.R.layout.channel2);

        Intent intent = getIntent();
        username = intent.getStringExtra("username");

        channelView = findViewById(com.example.fakenews.R.id.channel_view_2);

        button_close = (ImageView) findViewById(R.id.channel_category_close2);
        button_close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        init();
    }

    private void init() {

        userChannelList = NewsManager.getTopMenu(username);
        otherChannelList = NewsManager.getTopMenuOthers(username);
        if(userChannelList == null || userChannelList.size() == 0) {
            userChannelList = TopMenuChoice.getChoice();
            otherChannelList = TopMenuChoiceOthers.getChoice();
        }


        int i = 0;
        for (String the_channel : userChannelList) {
            Channel channel;
            channel = new Channel(the_channel, 2, (Object) i);
            i++;
            ch_userChannelList.add(channel);
        }

        for (String the_channel : otherChannelList) {
            Channel channel = new Channel(the_channel);
            ch_otherChannelList.add(channel);
        }

        channelView.setChannelFixedCount(1);
        channelView.addPlate("我的频道", ch_userChannelList);
        channelView.addPlate("推荐频道", ch_otherChannelList);

        channelView.inflateData();
        channelView.setOnChannelItemClickListener(new ChannelView.OnChannelListener() {
            @Override
            public void channelItemClick(int position, Channel channel) {

            }

            @Override
            public void channelEditFinish(List<Channel> channelList) {

            }

            @Override
            public void channelEditStart() {

            }
        });
    }

    private void saveChannel() {
        ArrayList<String> save_user_choices = new ArrayList<>();
        ArrayList<String> save_other_choices = new ArrayList<>();
        ch_userChannelList = channelView.getMyChannel();
        ch_otherChannelList = channelView.getOtherChannel().get(0);
        for(Channel channel : ch_userChannelList) {
            save_user_choices.add(channel.getChannelName());
        }
        for(Channel channel : ch_otherChannelList) {
            save_other_choices.add(channel.getChannelName());
        }

        TopMenuChoice.setChoice(save_user_choices);
        TopMenuChoiceOthers.setChoice(save_other_choices);

        NewsManager.updateTopMenu(username, save_user_choices, save_other_choices);
    }

    @Override
    public void onBackPressed() {
        saveChannel();
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        setResult(FragmentNews.CHANNELRESULT, intent);
        finish();
    }

}
