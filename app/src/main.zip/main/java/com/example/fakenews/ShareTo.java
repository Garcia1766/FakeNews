package com.example.fakenews;

import android.content.Intent;

import androidx.fragment.app.Fragment;

public class ShareTo extends Fragment {

    public void share(String subject, String body, String chooseTitle) {
        Intent sharingIntent = new Intent(Intent.ACTION_SEND);
        sharingIntent.setType("text/plain");

        sharingIntent.putExtra(Intent.EXTRA_SUBJECT, subject);
        sharingIntent.putExtra(Intent.EXTRA_TEXT, body);

        startActivity(Intent.createChooser(sharingIntent, chooseTitle));
    }
}
